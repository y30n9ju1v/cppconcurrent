//00_false_sharing1
#include <iostream>
#include <thread>
#include "chronometry.h"

constexpr int sz = 100000000;

long long n1 = 0;
long long n2 = 0;

void f1()
{
	for (int i = 0; i < sz; i++)
	{
		n1 += 1;
	}
}
void f2()
{
	for (int i = 0; i < sz; i++)
	{
		n2 += 1;
	}
}

void single_thread()
{
	StopWatch sw(true);
	f1();
	f2();
}
void multi_thread()
{
	StopWatch sw(true);
	f1();
	f2();
}


int main()
{
	chronometry(single_thread);
	chronometry(multi_thread);
}
