//00_false_sharing1
#include <iostream>
#include <thread>
#include "chronometry.h"

constexpr int sz = 10000;

int arr[sz][sz];

void f1()
{
	for (int i = 0; i < sz; i++)
	{
		for (int j = 0; j < sz; j++)
		{
			arr[i][j] = 0;
		}
	}
}
void f2()
{
	for (int i = 0; i < sz; i++)
	{
		for (int j = 0; j < sz; j++)
		{
			arr[j][i] = 0;
		}
	}
}

int main()
{
	chronometry(f1);
	chronometry(f2);
}
