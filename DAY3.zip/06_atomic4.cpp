#include <iostream>
#include <thread>
#include <atomic>

struct Point { int x, y; };

std::atomic<int> a1;

int main()
{
    ++a1; 
    int n = a1.load();
}

