#include <iostream>

int main()
{
	int v1 = 10, v2 = 20;

	int& r1 = v1;
	int& r2 = v2;

	r1 = r2;


	std::cout << v1 << std::endl;
	std::cout << v2 << std::endl;
	std::cout << r1 << std::endl;
	std::cout << r2 << std::endl;
}