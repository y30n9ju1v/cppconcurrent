#include <iostream>
#include <chrono>

void foo(std::chrono::seconds s) {} 


int main()
{
    // std::chrono::seconds => std::chrono::duration<int, std::ratio<1,1>>


}