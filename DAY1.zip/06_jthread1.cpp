#include <iostream>
#include <thread>

// join_thread 

void foo(int a, int b)
{
	std::cout << "foo : " << a << ", " << b << std::endl;
}

int main()
{
    std::thread t1(&foo, 10, 20);
	t1.join();
}

