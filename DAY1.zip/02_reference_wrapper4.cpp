#include <iostream>
#include <functional>

void foo(int n, int& r)
{
	r = 100;
}

int main()
{
	std::function<void(int)> f;
	
	int n = 0;

	f = std::bind(&foo, _1, n); 

	f(0);

	std::cout << n << std::endl;
}

