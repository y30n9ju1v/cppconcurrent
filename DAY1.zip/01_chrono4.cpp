#include <iostream>
#include <chrono>

int main()
{
    using seconds      = std::chrono::duration<int>; // duration<int, ratio<1,1>>
    using minutes      = std::chrono::duration<int, std::ratio<60,1>>;
    using hours        = std::chrono::duration<int, std::ratio<3600>>; // ratio<3600,1>
    using milliseconds = std::chrono::duration<int, milli>;


}