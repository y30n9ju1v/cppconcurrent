#include <iostream>
#include <ratio>

int main()
{
    std::ratio_add< ratio<1, 4>, ratio<2, 4> > r2; // 3/4


}